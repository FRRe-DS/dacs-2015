@javax.xml.bind.annotation.XmlSchema(namespace = "http://cuit.cs.frre.utn.edu.ar/")
package ar.edu.utn.frre.cs.cuit;
