package ar.edu.utn.frre.cs.model;

import ar.edu.utn.frre.cs.model.references.EstadoCivil;
import ar.edu.utn.frre.cs.model.references.Sexo;
import ar.edu.utn.frre.cs.model.references.TipoDocumento;
import java.util.Date;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(Cliente.class)
public abstract class Cliente_ {

	public static volatile SingularAttribute<Cliente, String> apellido2;
	public static volatile SingularAttribute<Cliente, String> telefono2;
	public static volatile SingularAttribute<Cliente, EstadoCivil> estadoCivil;
	public static volatile SingularAttribute<Cliente, String> apellido1;
	public static volatile SingularAttribute<Cliente, String> cuip;
	public static volatile SingularAttribute<Cliente, Long> numeroDocumento;
	public static volatile SingularAttribute<Cliente, String> telefono1;
	public static volatile SingularAttribute<Cliente, Sexo> sexo;
	public static volatile SingularAttribute<Cliente, Date> fechaNacimiento;
	public static volatile SingularAttribute<Cliente, String> primerNombre;
	public static volatile SingularAttribute<Cliente, Long> id;
	public static volatile SingularAttribute<Cliente, String> email;
	public static volatile SingularAttribute<Cliente, TipoDocumento> tipoDocumento;
	public static volatile SingularAttribute<Cliente, String> segundoNombre;

}

